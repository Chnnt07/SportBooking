
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="models.Court"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh sách sân thể thao</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f6fa;
            margin: 0;
            color: #263238;
        }
        header {
            background: #146c43;
            color: white;
            padding: 22px 8%;
        }
        header h1 { margin: 0; }
        main {
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .search-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 24px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        input, select, button {
            padding: 11px;
            border: 1px solid #ccd3da;
            border-radius: 6px;
            font-size: 14px;
        }
        input { flex: 1; min-width: 180px; }
        button {
            background: #146c43;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover { background: #0d5131; }
        .court-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 18px;
        }
        .court-card {
            background: white;
            padding: 22px;
            border-radius: 10px;
            box-shadow: 0 2px 8px #00000010;
        }
        .court-card h3 { margin-top: 0; }
        .type { color: #64748b; }
        .price {
            color: #146c43;
            font-size: 21px;
            font-weight: bold;
        }
        .status {
            display: inline-block;
            background: #dcfce7;
            color: #166534;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 12px;
        }
        .empty {
            background: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<header>
    <h1>SportBooking</h1>
    <p>Danh sách sân thể thao</p>
</header>

<main>
    <form class="search-box" action="CourtController" method="get">
        <input type="text" name="keyword"
               placeholder="Nhập tên sân cần tìm..."
               value="<%= request.getAttribute("keyword") == null
                   ? "" : request.getAttribute("keyword") %>">

        <select name="sportType">
            <option value="">Tất cả loại sân</option>
            <option value="Badminton">Cầu lông</option>
            <option value="Pickleball">Pickleball</option>
            <option value="Football">Bóng đá</option>
        </select>

        <button type="submit">Tìm kiếm</button>
        <a href="CourtController"
           style="padding:11px;text-decoration:none;color:#146c43">
            Xóa bộ lọc
        </a>
    </form>

    <div class="court-list">
        <%
            List<Court> courts =
                (List<Court>) request.getAttribute("courts");

            if (courts != null && !courts.isEmpty()) {
                for (Court court : courts) {
        %>
            <div class="court-card">
                <h3><%= court.getCourtName() %></h3>
                <p class="type">Loại sân: <%= court.getSportType() %></p>
                <p class="price">
                    <%= String.format("%,.0f", court.getPricePerHour()) %>
                    VNĐ/giờ
                </p>
                <span class="status">Đang hoạt động</span>
            </div>
        <%
                }
            } else {
        %>
            <div class="empty">
                Không tìm thấy sân phù hợp.
            </div>
        <%
            }
        %>
    </div>
</main>

</body>
</html>
