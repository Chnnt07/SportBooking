
package models;

public class Court {
    private int courtID;
    private String courtName;
    private String sportType;
    private double pricePerHour;
    private boolean active;

    public Court() {
    }

    public Court(int courtID, String courtName,
                 String sportType, double pricePerHour,
                 boolean active) {
        this.courtID = courtID;
        this.courtName = courtName;
        this.sportType = sportType;
        this.pricePerHour = pricePerHour;
        this.active = active;
    }

    public int getCourtID() {
        return courtID;
    }

    public void setCourtID(int courtID) {
        this.courtID = courtID;
    }

    public String getCourtName() {
        return courtName;
    }

    public void setCourtName(String courtName) {
        this.courtName = courtName;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public double getPricePerHour() {
        return pricePerHour;
    }

    public void setPricePerHour(double pricePerHour) {
        this.pricePerHour = pricePerHour;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
