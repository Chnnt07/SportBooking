
package controllers;

import dao.CourtDAO;
import java.io.IOException;
import java.util.List;
import models.Court;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "CourtController", urlPatterns = {"/CourtController"})
public class CourtController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String keyword = request.getParameter("keyword");
        String sportType = request.getParameter("sportType");

        CourtDAO dao = new CourtDAO();
        List<Court> courts;

        if ((keyword == null || keyword.trim().isEmpty())
                && (sportType == null || sportType.trim().isEmpty())) {
            courts = dao.getAllCourts();
        } else {
            courts = dao.searchCourts(keyword, sportType);
        }

        request.setAttribute("courts", courts);
        request.setAttribute("keyword", keyword == null ? "" : keyword);
        request.setAttribute("sportType",
                sportType == null ? "" : sportType);

        request.getRequestDispatcher("/courts.jsp")
               .forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        doGet(request, response);
    }
}
