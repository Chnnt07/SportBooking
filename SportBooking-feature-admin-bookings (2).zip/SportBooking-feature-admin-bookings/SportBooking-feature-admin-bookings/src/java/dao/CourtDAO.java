package dao;

import dal.DbContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Court;

public class CourtDAO extends DbContext {

    // Lay danh sach san dang hoat dong
    public List<Court> getAllCourts() {
        List<Court> list = new ArrayList<>();

        String sql = "SELECT CourtID, CourtName, SportType, "
                   + "PricePerHour, IsActive "
                   + "FROM dbo.Courts WHERE IsActive = 1";

        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Court court = new Court(
                    rs.getInt("CourtID"),
                    rs.getString("CourtName"),
                    rs.getString("SportType"),
                    rs.getDouble("PricePerHour"),
                    rs.getBoolean("IsActive")
                );
                list.add(court);
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // Tim kiem san theo ten va loai the thao
    public List<Court> searchCourts(String keyword, String sportType) {
        List<Court> list = new ArrayList<>();

        String sql = "SELECT CourtID, CourtName, SportType, "
                   + "PricePerHour, IsActive "
                   + "FROM dbo.Courts WHERE IsActive = 1 "
                   + "AND CourtName LIKE ? "
                   + "AND (? = '' OR SportType = ?)";

        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, "%" + (keyword == null ? "" : keyword.trim()) + "%");
            ps.setString(2, sportType == null ? "" : sportType.trim());
            ps.setString(3, sportType == null ? "" : sportType.trim());

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Court court = new Court(
                    rs.getInt("CourtID"),
                    rs.getString("CourtName"),
                    rs.getString("SportType"),
                    rs.getDouble("PricePerHour"),
                    rs.getBoolean("IsActive")
                );
                list.add(court);
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
